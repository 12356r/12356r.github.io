import type { PlantArtSpec, PlantForm } from '../components/PlantArt';
import type { SourceRef, Verification } from './types';

/**
 * 校园植物。
 *
 * 收录原则：
 * - 物种名称与形态描述：以 iPlant 植物智（中国科学院植物研究所）的物种信息为准，
 *   每条都给出该物种的页面链接，可逐条核对。
 * - 校园分布：来自一份公开流传的《郑州大学新校区校园植物》整理资料（第三方、非官方），
 *   因此标注为「分布待核验」，建议以校园现场挂牌与学校官方信息为准。
 */

export type PlantCategory = '乔木' | '花灌木' | '水生植物' | '地被与草本' | '藤本';

export interface Plant {
  id: string;
  name: string;
  latin: string;
  family: string;
  category: PlantCategory;
  /** 观赏期（花期或最佳观赏时段） */
  bloom: string;
  summary: string;
  features: string[];
  /** 校园内的大致分布（第三方资料） */
  spots: string[];
  art: PlantArtSpec;
  sources: SourceRef[];
  /** 物种信息的核验状态 */
  verification: Verification;
  /** 校园分布的核验状态 */
  distribution: Verification;
  updatedAt: string;
}

export const PLANT_SOURCE: SourceRef = {
  label: '《郑州大学新校区校园植物》整理资料（第三方，含分布记录）',
  url: 'https://www.renrendoc.com/paper/220592771.html',
};

function iplant(latin: string): SourceRef {
  return {
    label: `iPlant 植物智 · ${latin}`,
    url: `https://www.iplant.cn/info/${encodeURIComponent(latin)}`,
  };
}

const CREAM = '#f7f2e6';
const MINT = '#eef5ec';
const MIST = '#eef3f7';

const ROWS: Array<
  Omit<Plant, 'id' | 'sources' | 'verification' | 'distribution' | 'updatedAt' | 'art'> & {
    form: PlantForm;
    paletteArt: PlantArtSpec['palette'];
    seed: number;
    habit?: PlantArtSpec['habit'];
    inflorescence?: PlantArtSpec['inflorescence'];
    /** 覆盖默认来源 / 核验状态（项目方整理的条目会用到） */
    sources?: SourceRef[];
    verification?: Verification;
    distribution?: Verification;
  }
> = [
  {
    name: '银杏',
    latin: 'Ginkgo biloba',
    family: '银杏科 银杏属',
    category: '乔木',
    bloom: '4 月开花，10—11 月观叶',
    summary: '秋季最醒目的校园树种之一，扇形叶变黄后成片落地，是主校区秋天的标志性画面。',
    features: [
      '落叶乔木，叶扇形，顶缘常具缺刻或 2 裂，长枝上散生、短枝上簇生。',
      '雌雄异株，种子核果状，成熟时橙黄色、外被白粉。',
      '国家一级保护植物，被称为孑遗植物。',
    ],
    spots: ['五星广场及行政楼前两侧', '中心花园', '钟楼西侧', '培英路西段路南', '河园东路北段路西'],
    form: 'fan',
    paletteArt: { bg: CREAM, leaf: '#dcc95c', leafDark: '#b3a03c', flower: '#e9b45c', flowerDeep: '#c98d3a' },
    seed: 3,
  },
  {
    name: '白玉兰',
    latin: 'Magnolia denudata',
    family: '木兰科 木兰属',
    category: '乔木',
    bloom: '3 月，花期约 10 天',
    summary: '先花后叶，盛开时满树白花直立如烛，是早春最早被注意到的花树。',
    features: [
      '落叶乔木，冬芽密被淡灰绿色长毛。',
      '花白色、大型、芳香，先叶开放，直立呈钟状。',
      '聚合果，种子心脏形。',
    ],
    spots: ['中心花园北部', '核心区东侧', '培英路、毓秀路两侧', '假山顶部'],
    form: 'canopy',
    paletteArt: { bg: CREAM, leaf: '#88b491', leafDark: '#5f8f6b', flower: '#fdfbf8', flowerDeep: '#e9c9d2' },
    seed: 7,
  },
  {
    name: '桂花',
    latin: 'Osmanthus fragrans',
    family: '木犀科 木犀属',
    category: '乔木',
    bloom: '9—10 月，以香取胜',
    summary: '花小却极香，秋季走到树下常先闻到味道再看到花。',
    features: [
      '常绿阔叶乔木，树皮粗糙、灰褐色。',
      '叶对生、革质，椭圆形至披针形，全缘或上半部有细锯齿。',
      '花簇生叶腋，黄白色，芳香浓郁；常见丹桂、银桂、四季桂等品种。',
    ],
    spots: ['五星广场', '河园东路路东', '理科园', '菊园'],
    form: 'canopy',
    paletteArt: { bg: MINT, leaf: '#54845f', leafDark: '#39684a', flower: '#f3d27a', flowerDeep: '#d9ae45' },
    seed: 11,
  },
  {
    name: '紫薇',
    latin: 'Lagerstroemia indica',
    family: '千屈菜科 紫薇属',
    category: '花灌木',
    bloom: '6—9 月',
    summary: '树皮光滑、花期很长，轻抚树干整株会微微颤动，因而被叫作「痒痒树」。',
    features: [
      '落叶灌木或小乔木，树皮易脱落、树干光滑。',
      '花瓣 6 枚，边缘有不规则皱褶，红色或粉红色。',
      '圆锥花序顶生，花期可延续整个夏季。',
    ],
    spots: ['理科园', '文科园', '工科园', '南北一号教学楼顶花坛', '中心花园'],
    form: 'canopy',
    paletteArt: { bg: CREAM, leaf: '#7ba16c', leafDark: '#547a4d', flower: '#e58fae', flowerDeep: '#c46287' },
    seed: 13,
  },
  {
    name: '水杉',
    latin: 'Metasequoia glyptostroboides',
    family: '杉科 水杉属',
    category: '乔木',
    bloom: '秋末转红褐色',
    summary: '树干笔直、枝叶羽状对生，秋季由绿转红褐，是水岸边的竖向线条。',
    features: [
      '落叶乔木，小枝对生或近对生，常下垂。',
      '叶线形、交互对生，在侧生小枝上排成羽状二列。',
      '国家一级保护植物。',
    ],
    spots: ['校园超市西侧', '眉湖西岸', '元和广场西部'],
    form: 'conifer',
    paletteArt: { bg: MIST, leaf: '#79a37c', leafDark: '#4f7a58', flower: '#b98a5e', flowerDeep: '#8f6540' },
    seed: 17,
    habit: 'columnar',
  },
  {
    name: '油松',
    latin: 'Pinus tabuliformis',
    family: '松科 松属',
    category: '乔木',
    bloom: '4—5 月开花，四季常绿',
    summary: '校园里最稳定的常绿骨架之一，针叶成束、树冠在壮年呈塔形。',
    features: [
      '常绿乔木，树皮灰棕色、呈鳞片状开裂。',
      '叶 2 针一束，长 10—15 厘米，叶鞘宿存。',
      '球果卵形，种鳞背面有横脊，鳞脐有刺。',
    ],
    spots: ['眉湖南侧喷泉南部', '松园', '假山南麓'],
    form: 'conifer',
    paletteArt: { bg: MIST, leaf: '#4f7c5d', leafDark: '#33604a', flower: '#a8773f', flowerDeep: '#7d5327' },
    seed: 19,
  },
  {
    name: '木槿',
    latin: 'Hibiscus syriacus',
    family: '锦葵科 木槿属',
    category: '花灌木',
    bloom: '6—9 月',
    summary: '单瓣或重瓣的花每天开落，花期却能从初夏一直延续到开学。',
    features: [
      '落叶灌木或小乔木，高 3—6 米，茎直立多分枝。',
      '叶卵形或菱状卵形，常 3 裂，有明显三条主脉。',
      '花单生叶腋，花瓣 5，有浅蓝紫、粉红、白等花色。',
    ],
    spots: ['图书馆南北两侧'],
    form: 'canopy',
    paletteArt: { bg: MIST, leaf: '#77a072', leafDark: '#527a50', flower: '#e9a2c0', flowerDeep: '#c06e93' },
    seed: 23,
  },
  {
    name: '睡莲',
    latin: 'Nymphaea tetragona',
    family: '睡莲科 睡莲属',
    category: '水生植物',
    bloom: '5—9 月，多在白天开放',
    summary: '叶片浮在水面，花开在水上，是校园水景里最安静的一层。',
    features: [
      '多年生水生花卉，根状茎粗短。',
      '叶浮于水面，近圆形或卵状椭圆形，上面浓绿、下面暗紫。',
      '花单生于细长花柄顶端，多白色，直径 3—6 厘米。',
    ],
    spots: ['五星广场池塘', '眉湖北部', '环钟楼池塘'],
    form: 'aquatic',
    paletteArt: { bg: '#f2f6f8', leaf: '#6f9f78', leafDark: '#4a7a58', flower: '#fbf4f8', flowerDeep: '#e2c0d1' },
    seed: 29,
  },
  {
    name: '海桐',
    latin: 'Pittosporum tobira',
    family: '海桐花科 海桐花属',
    category: '花灌木',
    bloom: '5 月开花，9—10 月果熟',
    summary: '叶厚而亮、四季常绿，是楼前与花坛里最常见的一层矮灌。',
    features: [
      '常绿灌木或小乔木，高达 3 米，枝叶密生。',
      '叶聚生枝顶、厚革质，倒卵形，表面亮绿色，新叶黃嫩。',
      '花白色或带黄绿色，芳香；果实成熟后 3 瓣裂，种子鲜红色。',
    ],
    spots: ['南北一号教学楼顶花坛', '行政楼东西侧', '眉湖东岸'],
    form: 'canopy',
    paletteArt: { bg: MINT, leaf: '#4f8a66', leafDark: '#356b4c', flower: '#f7f4e6', flowerDeep: '#c9c49a' },
    seed: 31,
  },
  {
    name: '红花酢浆草',
    latin: 'Oxalis corymbosa',
    family: '酢浆草科 酢浆草属',
    category: '地被与草本',
    bloom: '4—10 月',
    summary: '三片心形小叶贴地铺开，花叶白天舒展、夜间与阴雨天闭合。',
    features: [
      '多年生草本，株高 10—20 厘米，地下具球形根状茎。',
      '三小叶复叶，小叶倒心形，三角状排列。',
      '伞形花序顶生，花粉红色；花与叶对光敏感，昼开夜合。',
    ],
    spots: ['校园绿地边缘与树下（资料未逐处标注）'],
    form: 'ground',
    paletteArt: { bg: MINT, leaf: '#6da86a', leafDark: '#4b8149', flower: '#e57ba1', flowerDeep: '#c05079' },
    seed: 37,
  },
  {
    name: '千屈菜',
    latin: 'Lythrum salicaria',
    family: '千屈菜科 千屈菜属',
    category: '水生植物',
    bloom: '7—9 月',
    summary: '水岸边成片的紫色穗状花序，是眉湖西岸夏季最集中的一抹颜色。',
    features: [
      '多年生草本，高达 1 米，多分枝，枝四至六棱。',
      '叶对生或 3 枚轮生，狭披针形，基部圆形或心形。',
      '花紫色，组成顶生大型穗状花序，花瓣 6 枚。',
    ],
    spots: ['眉湖西岸'],
    form: 'aquatic',
    paletteArt: { bg: '#f4f1f7', leaf: '#6f9c6a', leafDark: '#4f7a4c', flower: '#c07ac0', flowerDeep: '#95518f' },
    seed: 41,
  },
  {
    name: '凌霄',
    latin: 'Campsis grandiflora',
    family: '紫葳科 凌霄属',
    category: '藤本',
    bloom: '7—8 月',
    summary: '靠气生根攀附墙面与廊架，盛夏垂下一串串橙红色的喇叭花。',
    features: [
      '落叶藤本，茎上有攀缘的气生根，可长达 10 余米。',
      '奇数羽状复叶对生，小叶 7—9 枚，边缘有锯齿。',
      '花冠漏斗状、唇形五裂，鲜红或桔红色。',
    ],
    spots: ['启明广场北侧', '菊园'],
    form: 'vine',
    paletteArt: { bg: CREAM, leaf: '#6f9a66', leafDark: '#4f7a48', flower: '#e2703f', flowerDeep: '#b04c26' },
    seed: 43,
  },
  {
    name: '芦苇',
    latin: 'Phragmites australis',
    family: '禾本科 芦苇属',
    category: '水生植物',
    bloom: '夏秋抽穗，秋冬观穗',
    summary: '水边高草，风一过整片起伏，秋冬的花穗留在岸边过季。',
    features: [
      '多年生水生或湿生高大禾草，具粗壮匍匐根状茎。',
      '叶片长线形或长披针形，排列成两行。',
      '圆锥花序稠密、向斜伸展，小穗含数朵小花。',
    ],
    spots: ['眉湖北部'],
    form: 'ground',
    paletteArt: { bg: '#f2f5ee', leaf: '#8ba578', leafDark: '#6a8760', flower: '#d8c9a4', flowerDeep: '#b3a07a' },
    seed: 47,
    inflorescence: 'plume',
  },
  {
    name: '水烛香蒲',
    latin: 'Typha angustifolia',
    family: '香蒲科 香蒲属',
    category: '水生植物',
    bloom: '6—8 月花果期',
    summary: '花序像一支插在水里的褐色蜡烛，是湿地水岸很有辨识度的竖线。',
    features: [
      '挺水植物，植株高约 1—1.5 米。',
      '叶片扁平、狭长线形，宽 5—8 毫米。',
      '穗状花序雌雄同株，雌花序圆柱形、红褐色，形似蜡烛。',
    ],
    spots: ['眉湖'],
    form: 'aquatic',
    paletteArt: { bg: '#f3f2ec', leaf: '#7d9a6a', leafDark: '#5d7a4c', flower: '#9a6a44', flowerDeep: '#6f4526' },
    seed: 53,
  },
];

/**
 * 第二批：来自项目方整理的《郑大植物》文档（2026-10）。
 * 这些条目的形态与观赏描述由项目方撰写，校园分布也由项目方指出；
 * 物种拉丁名与科属按通行分类填写，可到 iPlant 逐条核对。
 */
const OWNER_ROWS: typeof ROWS = [
  {
    name: '红叶石楠',
    latin: 'Photinia × fraseri',
    family: '蔷薇科 石楠属',
    category: '花灌木',
    bloom: '春秋新叶火红，夏季转深绿',
    summary: '校园绿化带里最常见的「常驻明星」：新叶通红、老叶翠绿，常被修剪成圆润的球形，一排排守在道路两侧。',
    features: [
      '四季常绿灌木，新梢嫩叶呈鲜艳火红色，红绿交替、层次分明。',
      '耐修剪、长势快、成活率高，最常被修成球形绿篱。',
      '整齐排布在道路两侧，是校园里最容易被认出来的绿化植物之一。',
    ],
    spots: ['道路两侧绿化带', '各园区绿篱'],
    form: 'canopy',
    paletteArt: { bg: '#f7f0ea', leaf: '#c0453c', leafDark: '#7d8f5a', flower: '#e8e2d8', flowerDeep: '#c7bfae' },
    seed: 59,
    sources: [iplant('Photinia fraseri')],
    verification: 'verified',
    distribution: 'verified',
  },
  {
    name: '凤尾丝兰',
    latin: 'Yucca gloriosa',
    family: '天门冬科 丝兰属',
    category: '花灌木',
    bloom: '花期抽出高花茎，白色铃铛状小花垂挂',
    summary: '路边最利落的绿植：叶片修长坚硬、向外舒展，开花时抽出一串洁白铃铛形小花，素雅又耐看。',
    features: [
      '叶片修长坚硬、整齐挺拔，呈放射状外展，形态干净利落。',
      '花期会长出很高的花茎，白色铃铛状小花成串下垂。',
      '耐寒、耐旱、耐暴晒，四季常绿，是道路两旁最稳重的绿化植物。',
    ],
    spots: ['校园道路两旁'],
    form: 'ground',
    inflorescence: 'plume',
    paletteArt: { bg: '#f2f4ea', leaf: '#6e8a5c', leafDark: '#4d6740', flower: '#fdfcf6', flowerDeep: '#e0ddc8' },
    seed: 61,
    sources: [iplant('Yucca gloriosa')],
    verification: 'verified',
    distribution: 'verified',
  },
  {
    name: '五彩苏',
    latin: 'Coleus scutellarioides',
    family: '唇形科 鞘蕊花属',
    category: '地被与草本',
    bloom: '全年观叶，越晒色彩越鲜亮',
    summary: '花坛里的「颜值担当」：不靠花，光凭叶片就够热闹——深红、玫红、金黄、翠绿、紫边层层交织。',
    features: [
      '叶片色彩丰富，多种颜色与紫边层层交织，质感如丝绒。',
      '越晒太阳颜色越鲜亮通透，成片种植时五颜六色。',
      '长势快、四季有色彩，是校园里最活泼的观叶植物。',
    ],
    spots: ['校园花坛'],
    form: 'ground',
    paletteArt: { bg: '#f8f1ea', leaf: '#b4477a', leafDark: '#6f8a3f', flower: '#f0c14b', flowerDeep: '#c98a2e' },
    seed: 67,
    sources: [iplant('Coleus scutellarioides')],
    verification: 'verified',
    distribution: 'verified',
  },
  {
    name: '南天竹',
    latin: 'Nandina domestica',
    family: '小檗科 南天竹属',
    category: '花灌木',
    bloom: '秋冬叶转橙红，红果满枝',
    summary: '秋冬的配色担当：春夏整株翠绿，入秋叶片渐渐转成橙红，枝头挂满一串串圆润的红色小果。',
    features: [
      '四季常青，入秋入冬叶片变为橙红、艳红色。',
      '果序成串，小果圆润饱满、鲜红，观果期长。',
      '姿态优雅、枝叶轻盈，是园林造景里经典的配色植物。',
    ],
    spots: ['校园绿化带'],
    form: 'canopy',
    paletteArt: { bg: '#f7f0ec', leaf: '#a8543c', leafDark: '#5f7a49', flower: '#e05a4a', flowerDeep: '#b23227' },
    seed: 71,
    sources: [iplant('Nandina domestica')],
    verification: 'verified',
    distribution: 'verified',
  },
  {
    name: '荇菜',
    latin: 'Nymphoides peltata',
    family: '睡菜科 荇菜属',
    category: '水生植物',
    bloom: '夏秋开小黄花',
    summary: '《诗经》里「参差荇菜，左右流之」说的就是它。叶片圆圆嫩嫩漂在水面，星星点点的小黄花缀在碧水间。',
    features: [
      '浮叶水生植物，叶片圆形、漂浮于水面。',
      '花黄色、小巧，成片开放时点缀在湖面上。',
      '对水质要求较高，多见于干净清澈的水体。',
    ],
    spots: ['校园湖面'],
    form: 'aquatic',
    paletteArt: { bg: '#eef4f2', leaf: '#6f9a68', leafDark: '#4d7448', flower: '#f2c94c', flowerDeep: '#c99a2e' },
    seed: 73,
    sources: [iplant('Nymphoides peltata')],
    verification: 'verified',
    distribution: 'verified',
  },
  {
    name: '彼岸花',
    latin: 'Lycoris radiata',
    family: '石蒜科 石蒜属',
    category: '地被与草本',
    bloom: '秋季开花，花叶不相见',
    summary: '花叶永不相见：花开时没有叶，长叶时没有花。秋季忽然从地里抽出鲜红的花，安静又惊艳。',
    features: [
      '多年生草本，花叶不相见，花期不见叶、叶期不见花。',
      '花瓣细长反卷，鲜红色，形态飘逸。',
      '多生于林下、林缘等半阴环境，秋季开放。',
    ],
    spots: ['校园绿地'],
    form: 'ground',
    paletteArt: { bg: '#f7efec', leaf: '#6f8a5a', leafDark: '#4f6840', flower: '#c8392f', flowerDeep: '#8f231c' },
    seed: 79,
    sources: [iplant('Lycoris radiata')],
    verification: 'verified',
    distribution: 'verified',
  },
  {
    name: '五指榆',
    latin: 'Ulmus pumila',
    family: '榆科 榆属',
    category: '乔木',
    bloom: '春季开花结果',
    summary: '校园里很有辨识度的一株老榆树：树干底部自然分出五个主干，像一只张开的手掌，所以被叫作「五指榆」。',
    features: [
      '榆树，树干基部分出五条主干，形如张开的五指，因而得名。',
      '树姿挺拔苍劲，树皮纹理厚重，自带岁月感。',
      '长势旺盛、枝繁叶茂，是校园里的标志性古树之一。',
    ],
    spots: ['钟楼广场附近'],
    form: 'canopy',
    paletteArt: { bg: '#f6f1e6', leaf: '#6e8a55', leafDark: '#4a6440', flower: '#cbb98f', flowerDeep: '#a8916a' },
    seed: 83,
    sources: [iplant('Ulmus pumila')],
    verification: 'verified',
    distribution: 'verified',
  },
  {
    name: '金丝桃',
    latin: 'Hypericum monogynum',
    family: '金丝桃科 金丝桃属',
    category: '花灌木',
    bloom: '初夏至盛夏，金黄花丝',
    summary: '花瓣是干净的鹅黄，最惊艳的是中间那一大把细长金黄的花蕊，阳光底下像撒了碎金。',
    features: [
      '花金黄色，花瓣 5 枚；雄蕊细长、密集，呈金丝状。',
      '花期在初夏至盛夏，成片开放时金灿灿一片。',
      '耐晒耐热，花期长，常种在花坛与路边。',
    ],
    spots: ['校园花坛'],
    form: 'canopy',
    paletteArt: { bg: '#fbf6e6', leaf: '#6f8f5c', leafDark: '#4d6840', flower: '#f2c218', flowerDeep: '#c99a12' },
    seed: 89,
    sources: [iplant('Hypericum monogynum')],
    verification: 'verified',
    distribution: 'verified',
  },
  {
    name: '玉簪',
    latin: 'Hosta plantaginea',
    family: '天门冬科 玉簪属',
    category: '地被与草本',
    bloom: '夏季傍晚开花，清香',
    summary: '树荫下最温柔的植物：宽大的绿叶干净透亮，花苞细长洁白，像古代女子发髻上的白玉簪。',
    features: [
      '多年生草本，叶基生、宽大翠绿，喜阴湿环境。',
      '花白色、细长如簪，多在傍晚开放，有淡淡清香。',
      '常种在大树底下、阴凉步道旁。',
    ],
    spots: ['大树底下、阴凉步道旁'],
    form: 'ground',
    paletteArt: { bg: '#f2f4ee', leaf: '#5f8a58', leafDark: '#42663f', flower: '#fbf8f4', flowerDeep: '#ddd6c8' },
    seed: 97,
    sources: [iplant('Hosta plantaginea')],
    verification: 'verified',
    distribution: 'verified',
  },
  {
    name: '金银忍冬',
    latin: 'Lonicera maackii',
    family: '忍冬科 忍冬属',
    category: '花灌木',
    bloom: '5—6 月开花，秋季红果',
    summary: '一树两色花：刚开时银白，过几天变成金黄，「金银」之名由此而来；秋末枝头挂满红色小果。',
    features: [
      '花初开为银白色，后渐变为金黄色，同株可见两色花。',
      '浆果球形、红色，秋季成串挂满枝头。',
      '耐寒、易养活，是校园里常见的观赏灌木。',
    ],
    spots: ['校园绿化带'],
    form: 'canopy',
    paletteArt: { bg: '#f7f3ea', leaf: '#6f8a5c', leafDark: '#4d6840', flower: '#fdf8ee', flowerDeep: '#e8c34a' },
    seed: 101,
    sources: [iplant('Lonicera maackii')],
    verification: 'verified',
    distribution: 'verified',
  },
];

const ALL_ROWS = [...ROWS, ...OWNER_ROWS];

export const PLANTS: Plant[] = ALL_ROWS.map((row) => ({
  id: `plant-${row.latin.toLowerCase().replace(/[^a-z]+/g, '-')}`,
  name: row.name,
  latin: row.latin,
  family: row.family,
  category: row.category,
  bloom: row.bloom,
  summary: row.summary,
  features: row.features,
  spots: row.spots,
  art: {
    form: row.form,
    palette: row.paletteArt,
    seed: row.seed,
    habit: row.habit,
    inflorescence: row.inflorescence,
  },
  sources: row.sources ?? [iplant(row.latin), PLANT_SOURCE],
  verification: row.verification ?? 'verified',
  distribution: row.distribution ?? 'pending',
  updatedAt: '2026-10-21',
}));

export const PLANT_CATEGORIES: Array<'全部' | PlantCategory> = [
  '全部',
  '乔木',
  '花灌木',
  '水生植物',
  '地被与草本',
  '藤本',
];
